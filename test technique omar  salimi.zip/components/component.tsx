import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";

export type ComponentType = {
  aIProspectsMarketSizeAndD?: string;
  theAIMarketIsOneOfTheMost?: string;
  aiCloudConceptWithRobotHe?: string;

  /** Style props */
  propLineHeight?: CSSProperties["lineHeight"];
  propHeight?: CSSProperties["height"];
};

const Component: NextPage<ComponentType> = ({
  aIProspectsMarketSizeAndD,
  theAIMarketIsOneOfTheMost,
  aiCloudConceptWithRobotHe,
  propLineHeight,
  propHeight,
}) => {
  const aIProspectsMarketStyle: CSSProperties = useMemo(() => {
    return {
      lineHeight: propLineHeight,
    };
  }, [propLineHeight]);

  const theAIMarketStyle: CSSProperties = useMemo(() => {
    return {
      height: propHeight,
    };
  }, [propHeight]);

  return (
    <div className="w-[1440px] rounded-md bg-gray overflow-hidden flex flex-row items-start justify-start py-0 pr-0 pl-10 box-border gap-[40px] max-w-full text-left text-19xl text-white font-monument-extended mq925:gap-[20px] mq1350:flex-wrap mq1350:pl-5 mq1350:pr-5 mq1350:pb-5 mq1350:box-border">
      <div className="flex-1 flex flex-col items-start justify-start pt-10 px-0 pb-0 box-border min-w-[590px] max-w-full mq925:min-w-full">
        <div className="self-stretch flex flex-col items-start justify-start gap-[15px]">
          <h1
            className="m-0 self-stretch relative text-inherit leading-[120%] uppercase font-normal font-inherit mq925:text-11xl mq925:leading-[36px] mq450:text-4xl mq450:leading-[27px]"
            style={aIProspectsMarketStyle}
          >
            {aIProspectsMarketSizeAndD}
          </h1>
          <div
            className="self-stretch h-[115px] relative text-lg leading-[130%] font-satoshi inline-block"
            style={theAIMarketStyle}
          >
            {theAIMarketIsOneOfTheMost}
          </div>
        </div>
      </div>
      <div className="h-[302px] w-[453px] relative overflow-hidden shrink-0 min-w-[453px] max-w-full mq925:min-w-full mq1350:flex-1">
        <img
          className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] max-w-full overflow-hidden max-h-full object-cover mix-blend-luminosity"
          loading="lazy"
          alt=""
          src={aiCloudConceptWithRobotHe}
        />
        <div className="absolute h-full w-full top-[100%] right-[-100%] bottom-[-100%] left-[100%] [background:linear-gradient(174.64deg,_#3c6fff,_#9123ff_99.28%)] [transform:_rotate(-180deg)] [transform-origin:0_0] mix-blend-overlay z-[1]" />
      </div>
    </div>
  );
};

export default Component;
